# Camera Authentication App (PC + OBS)

Ứng dụng xác thực camera chạy trên trình duyệt, tối ưu cho **PC không có webcam**
thông qua **OBS Virtual Camera**. Phù hợp cho demo, nội bộ, staging, hoặc showcase kỹ thuật.

---

## ✨ Tính năng chính

- ✅ Frontend: React + Vite + TypeScript
- ✅ Backend: Node.js + Express + TypeScript
- ✅ Dùng được với **OBS Virtual Camera**
- ✅ Xác thực dựa trên session + thời gian
- ✅ CI/CD GitHub Actions
- ✅ Docker + GitHub Container Registry
- ✅ Blue-green deploy (zero downtime)
- ✅ Rollback theo version tag

---

## 🧩 Kiến trúc tổng quan

```
Browser (PC + OBS)
        |
        v
     NGINX
        |
        v
  Node.js Backend
```

---

## 🚀 Chạy local (developer)

### Backend
```bash
cd backend
npm install
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Mở trình duyệt:
```
http://localhost:5173
```

---

## 🐳 Chạy bằng Docker (production)

```bash
docker compose up -d
```

App chạy tại:
```
https://your-domain.com
```

---

## 📸 Dùng OBS Virtual Camera

1. Cài OBS Studio
2. Bật **Start Virtual Camera**
3. Mở app trên browser
4. Chọn **OBS Virtual Camera** khi browser hỏi quyền

---

## 🔁 Deploy & Rollback

### Deploy version mới
```bash
git tag v1.0.0
git push origin v1.0.0
```

→ GitHub Actions tự build & deploy

### Rollback
```bash
docker compose up -d
```
(sau khi đổi image tag về version cũ)

---

## ⚠️ Lưu ý

- Ứng dụng **không chống camera giả**
- Phù hợp cho demo, nội bộ, staging
- Không dùng cho thi cử / KYC pháp lý

---

## 📄 License
MIT
