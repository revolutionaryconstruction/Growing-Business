# Camera Authentication App – Release v1.0.0

## Overview
Browser-based camera authentication app packaged for Android using Trusted Web Activity (TWA).

## Technology
- React + TypeScript
- Node.js + Express
- Docker + CI/CD
- OBS Virtual Camera support

## Google Play
- Package: com.yourname.cameraauth
- Version: 1.0.0
- AAB: android/app-release.aab
- Privacy Policy: https://your-domain.com/privacy.html

## Notes
- No personal data collected
- Camera used only for real-time functionality
- No analytics, no ads
